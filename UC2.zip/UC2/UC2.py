import socket
import threading
import time
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import base64

# Función para validar la longitud de la clave de cifrado
def validar_clave_cifrado(clave):
    longitudes_validas = [16, 24, 32]
    if len(clave) not in longitudes_validas:
        raise ValueError(f"La clave de cifrado debe tener una longitud de {longitudes_validas} bytes. Longitud actual: {len(clave)}")

# Función para descifrar la clave de cifrado en formato base64
def obtener_clave_cifrado():
    clave_b64 = input("Introduce la clave de cifrado compartida (en base64): ")
    clave = base64.b64decode(clave_b64)
    validar_clave_cifrado(clave)
    return clave

# Generar una clave de cifrado de 16 bytes y mostrarla en base64
def generar_clave_cifrado():
    clave = get_random_bytes(16)  # Puedes cambiar a 24 o 32 bytes si lo prefieres
    print("Clave de cifrado generada (en base64):", base64.b64encode(clave).decode('utf-8'))
    return clave

# Para generar una nueva clave, descomenta la siguiente línea:
# clave_cifrado = generar_clave_cifrado()

# Para usar una clave existente, comenta la línea anterior y descomenta la siguiente:
clave_cifrado = obtener_clave_cifrado()

# Función para cifrar texto
def encrypt_text(key, text):
    iv = get_random_bytes(AES.block_size)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted_text = cipher.encrypt(pad(text.encode(), AES.block_size))
    return base64.b64encode(iv + encrypted_text).decode('utf-8')

# Función para descifrar texto
def decrypt_text(key, encrypted_text):
    encrypted_data = base64.b64decode(encrypted_text)
    iv = encrypted_data[:AES.block_size]
    encrypted_text = encrypted_data[AES.block_size:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted_text = unpad(cipher.decrypt(encrypted_text), AES.block_size)
    return decrypted_text.decode('utf-8')

# Función para manejar la comunicación con un cliente específico
def manejar_cliente(cliente, direccion):
    print(f"Conexión establecida con {direccion}")

    while True:
        try:
            datos = cliente.recv(1024)
            if not datos:
                break
            mensaje = decrypt_text(clave_cifrado, datos.decode())
            print(f"\nCliente {direccion}: {mensaje}")
        except (ConnectionResetError, ValueError, KeyError):
            print(f"\nCliente {direccion} desconectado o mensaje inválido")
            break

    cliente.close()

# Función para enviar mensajes desde el servidor a un cliente específico
def enviar_mensaje(cliente):
    while True:
        try:
            mensaje = input("Servidor: ")
            mensaje_cifrado = encrypt_text(clave_cifrado, mensaje)
            cliente.send(mensaje_cifrado.encode())
        except ConnectionResetError:
            print("Error de conexión. Intentando reconectar...")
            cliente.close()
            time.sleep(1)
            cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            intentar_conectar(cliente)
            continue

# Función para intentar conectar el cliente al servidor
def intentar_conectar(cliente):
    while True:
        try:
            cliente.connect(('127.0.0.1', 8080))  # Puerto y IP del UC1
            break
        except ConnectionRefusedError:
            print("No se pudo establecer conexión. Reintentando ...")
            time.sleep(1)

# Función principal del programa
def main():
    while True:
        try:
            servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            servidor.bind(('127.0.0.1', 8081))
            servidor.listen()

            print("Esperando conexiones...")

            cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            intentar_conectar(cliente)

            cliente_thread = threading.Thread(target=enviar_mensaje, args=(cliente,))
            cliente_thread.start()

            while True:
                cliente_conectado, direccion = servidor.accept()
                cliente_thread = threading.Thread(target=manejar_cliente, args=(cliente_conectado, direccion))
                cliente_thread.start()

        except Exception as e:
            print(f"Error: {e}")

        finally:
            servidor.close()
            cliente.close()

if __name__ == "__main__":
    main()

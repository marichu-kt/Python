import socket
import threading
import time
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import base64

# FUNCIÓN PARA VALIDAR LA LONGITUD DE LA CLAVE DE CIFRADO
def validar_clave_cifrado(clave):
    longitudes_validas = [16, 24, 32]                       # [128, 192, 256] BITS
    if len(clave) not in longitudes_validas:                # CREAMOS UNA EXCEPCIÓN EN CASO DE QUE LA CLAVE NO ESTÉ EN BASE 64
        raise ValueError(f"La clave de cifrado debe tener una longitud de {longitudes_validas} bytes. Longitud actual: {len(clave)}")

# FUNCIÓN PARA DESCIFRAR LA CLAVE DE CIFRADO EN FORMATO BASE 64
def obtener_clave_cifrado():
    clave_b64 = input("Introduce la clave de cifrado compartida (en base64): ")
    clave = base64.b64decode(clave_b64)
    validar_clave_cifrado(clave)
    return clave

# GENERAR UNA CLAVE DE CIFRADO DE 16 BYTES Y MOSTRARLA EN BASE64
def generar_clave_cifrado():
    clave = get_random_bytes(16)                             # CLAVE RANDOM DE 16 BYTES
    print("Clave de cifrado generada (en base64):", base64.b64encode(clave).decode('utf-8'))
    return clave

# FUNCIÓN PARA GENERAR UNA NUEVA CLAVE ALEATORIA
# clave_cifrado = generar_clave_cifrado()

# FUNCIÓN PARA USAR UNA CLAVE EXISTENTE
clave_cifrado = obtener_clave_cifrado()

# FUNCIÓN PARA CIFRAR TEXTO
def encrypt_text(key, text):
    iv = get_random_bytes(AES.block_size)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted_text = cipher.encrypt(pad(text.encode(), AES.block_size))
    return base64.b64encode(iv + encrypted_text).decode('utf-8')

# FUNCIÓN PARA DESCIFRAR TEXTO
def decrypt_text(key, encrypted_text):
    encrypted_data = base64.b64decode(encrypted_text)
    iv = encrypted_data[:AES.block_size]
    encrypted_text = encrypted_data[AES.block_size:]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted_text = unpad(cipher.decrypt(encrypted_text), AES.block_size)
    return decrypted_text.decode('utf-8')

# FUNCIÓN PARA MANEJAR LA COMUNICACIÓN CON EL CLIENTE ESPECIFICADO
def manejar_cliente(cliente, direccion):
    print(f"Conexión establecida con {direccion}")

    while True:
        try:
            datos = cliente.recv(1024)
            if not datos:
                break
            mensaje = decrypt_text(clave_cifrado, datos.decode())
            print(f"\nCliente {direccion}: {mensaje}")
        except (ConnectionResetError, ValueError, KeyError):
            print(f"\nCliente {direccion} desconectado o mensaje inválido")
            break

    cliente.close()

# FUNCIÓN PARA ENVIAR MENSAJES DESDE EL SERVIDOR AL CLIENTE ESPECIFICADO
def enviar_mensaje(cliente):
    while True:
        try:
            mensaje = input("Servidor: ")
            mensaje_cifrado = encrypt_text(clave_cifrado, mensaje)
            cliente.send(mensaje_cifrado.encode())
        except ConnectionResetError:
            print("Error de conexión. Intentando reconectar...")
            cliente.close()
            time.sleep(1)
            cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            intentar_conectar(cliente)
            continue

# FUNCIÓN PARA INTENTAR CONECTAR EL CLIENTE AL SERVIDOR
def intentar_conectar(cliente, ip, puerto):
    while True:
        try:
            cliente.connect((ip, puerto))
            break
        except ConnectionRefusedError:
            print("No se pudo establecer conexión. Reintentando ...")
            time.sleep(1)

# INTERFAZ DEL USUARIO
def main():
    ip_servidor = input("Introduce la IP del servidor UC2: ")
    puerto_servidor = int(input("Introduce el puerto del servidor UC2: "))
    
    ip_cliente = input("Introduce la IP del cliente UC1: ")
    puerto_cliente = int(input("Introduce el puerto del cliente UC1: "))
    
    while True:
        try:
            servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            servidor.bind((ip_servidor, puerto_servidor))
            servidor.listen()

            print("Esperando conexiones...")

            cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            intentar_conectar(cliente, ip_cliente, puerto_cliente)

            cliente_thread = threading.Thread(target=enviar_mensaje, args=(cliente,))
            cliente_thread.start()

            while True:
                cliente_conectado, direccion = servidor.accept()
                cliente_thread = threading.Thread(target=manejar_cliente, args=(cliente_conectado, direccion))
                cliente_thread.start()

        except Exception as e:
            print(f"Error: {e}")

        finally:
            servidor.close()
            cliente.close()

if __name__ == "__main__":
    main()

